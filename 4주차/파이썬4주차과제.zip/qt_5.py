h = int(input("시간을 입력하시오:   "))
m = int(input("분을 입력하시오:    "))
s = h*3600 + m*60
print(f"{h} 시간 {m} 분은 {s} 초입니다.")