a = int(input("삼각형의 첫 번째 변의 길이:   "))
b = int(input("삼각형의 두 번째 변의 길이:   "))
c = a+b-1
print(f"삼각형의 나머지 변의 최대 길이 = {c}")