cookie = 52
person = 3

print(f"과자의 개수: {cookie}")
print(f"한 사람당 나누어주는 과자의 개수: {person}")
print(f"최대 {cookie/person:.0f}명에게 나누어줄 수 있습니다.")
print(f"남는 과자는 {cookie%person}개 입니다.")