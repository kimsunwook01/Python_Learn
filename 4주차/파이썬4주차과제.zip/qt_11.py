a, b = 10, 20
print(f"바꾸기 전: a = {a}, b = {b}")
a, b = b, a
print(f"바꾸기 후: a = {a}, b = {b}")