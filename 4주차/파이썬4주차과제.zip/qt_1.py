x = int(input("x: "))
y = int(input("y: "))

add = x + y
minus = x - y
multipl = x * y
avg = (x + y)/2
maxnum = max(x, y)
minnum = min(x, y)

print(f"두 수의 합: {add}")
print(f"두 수의 차: {minus}")
print(f"두 수의 곱: {multipl}")
print(f"두 수의 평균: {avg}")
print(f"큰수: {maxnum}")
print(f"작은수: {minnum}")