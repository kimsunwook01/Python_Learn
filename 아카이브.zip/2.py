import turtle
t = turtle.Turtle()
t.shape("arrow")
t.forward(100)
t.right(120)
t.forward(100)
t.right(120)
t.forward(100)
t.right(120)
t.forward(100)
t.right(90)
t.forward(100)

