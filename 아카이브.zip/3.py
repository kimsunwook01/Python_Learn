# 두 수의 합 계산
x = 100
y = 200
sum = x + y
print("합은", sum)