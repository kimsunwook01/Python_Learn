print(2+3)
print(2-3)
print(2*3)
print(2/3)

print("강아지"+"고양이")
print("반가워요"*10)
print("100"+"200")
print(100+200)