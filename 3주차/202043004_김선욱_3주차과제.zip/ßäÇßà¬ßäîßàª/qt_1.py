# 닭2, 돼지4, 소3 마리의 전체 다리 수 구하기

# 닭, 돼지, 소의 마릿수
chicken = 2
pig = 4
cow = 3

# 각 동물의 다릿수
ckLeg = chicken * 2
pigLeg = pig * 4
cowLeg = cow * 4

# 모든 동물의 다릿수
allLeg = ckLeg + pigLeg + cowLeg

# 결과 출력
print(f"닭의 수: {chicken}\n돼지의 수: {pig}\n소의 수: {cow}")
print(f"\n전체 다리의 수: {allLeg}")